   <section style="background-color: cornflowerblue;"class="page-banner mb-1">
        <div class="services-image d-lg-flex align-items-center">
            
            <div style="padding-left: 20px;"class="image-responsive">
                  
              <img style="width: 400px; padding-left: 20px; padding-right: 20px;" src="assets/images/logos/logo_2.png" alt="Services">

              <img style="width: 40px;" src="assets/images/logos/corner1.png" alt="Services">
            </div>

            

            <center>

        <div class="container">

            <h1 class="sub-title" style="padding-left: 100px; text-align: justify; font-size: 100px; font-family: villalemana;text-align: right; text-align: center; color: white;"> VILLA ALEMANA <br>BENEFICIOS </h1><h3 class="page-title" style="color: white;"></h3>



              

            <div style="width: auto" class="container">

              <!--<span style="color: white; font-size: 26px;"> BENEFICIOS MUNICIPALES 2020</span>-->
              
              <!-- <button type="button" class="btn btn-primary btn-lg btn-block"><span class="add-on"><i class="fa fas-phone-volume"></i></span>Fono Atención telefonica - 800 400 050</button>-->
              <!-- <button type="button" class="btn btn-secondary btn-lg btn-block"><i class="fa fa-paper-plane"></i> beneficios@villalemana.cl</button> -->
            </div>

            
            
            
            
            
            </div>
            
            </div>
        

        </div> <!-- container -->

              

              
        </center>
      
       </section>



  
    
     

        <!--Carousel Wrapper-->
        <section  class="services-area  mb-1">
            
            
    
            <div style="width: auto;" class="container">
                <div class="row">

                    <img style="width: 300px; " class="card-title" src="assets/images/beneficios/imagen.png" alt="Card image cap">

                    
                    <div class="col-lg-10">
                            <h1 class="lead" style="text-align: justify; font-size: 25px; font-family: Arial;">El Municipio de Villa Alemana ha creado esta nueva plataforma para que puedas acceder a todos los beneficios que tenemos para ti.

                </h1>
                <br>

                <h1 class="lead" style="text-align: justify; font-size: 25px; font-family: Arial;">
                    Si tienes Registro Social de Hogares, perteneces a la población vulnerable de la comuna o a la clase media más necesitada, consulta si eres beneficiario o inscríbete para ser evaluado y así, acceder a las opciones que el municipio tiene disponible para la comunidad.
                    <br>
                    <br>
                </h1>
                <center><a style="text-align: justify; height: 50px; font-size: 20px;"href="consultasbeneficios" class="btn btn-warning" role="button" style="color:white; font-size: 50px;"><strong>Consulta aquí</strong> <i class="fa fa-mouse-pointer" style="color: white; "></i></a></center>
                    
                    
                    
                
                </div>
             </div>
        </section>