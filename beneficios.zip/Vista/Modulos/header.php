   <section style="background-color: cornflowerblue;"class="page-banner mb-20">
        <div class="services-image d-lg-flex align-items-center">
            <div class="image">
                
                <img style="width: 500px;" src="assets/images/logos/logo_2.png" alt="Services">
                
            </div>
        <div class="container">

            <h1 class="sub-title" style="font-size: 80px; font-family: villalemana; padding-right: 60px; text-align: right; text-align: center; color: white;">VILLA ALEMANA <br>BENEFICIOS</h1><h3 class="page-title" style="color: white;"></h3>


            <div style="width: auto" class="container">

              <!--<span style="color: white; font-size: 26px;"> BENEFICIOS MUNICIPALES 2020</span>-->
              
              <!-- <button type="button" class="btn btn-primary btn-lg btn-block"><span class="add-on"><i class="fa fas-phone-volume"></i></span>Fono Atención telefonica - 800 400 050</button>-->
              <!-- <button type="button" class="btn btn-secondary btn-lg btn-block"><i class="fa fa-paper-plane"></i> beneficios@villalemana.cl</button> -->
            </div>

            
            <div style="width: 1000px" class="container">

              <!--<span style="font-size: 26px; color: white;"> beneficios@villalemana.cl </span>-->
              <img style="width: 350px;" src="assets/images/banner.png" alt="Services" align="right">
              <!-- <button type="button" class="btn btn-primary btn-lg btn-block"><span class="add-on"><i class="fa fas-phone-volume"></i></span>Fono Atención telefonica - 800 400 050</button>-->
              <!-- <button type="button" class="btn btn-secondary btn-lg btn-block"><i class="fa fa-paper-plane"></i> beneficios@villalemana.cl</button> -->
            </div>
            
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="page-banner-content text-center">
                       <!--  <h3 class="page-title">Servicio e integridad</h3>-->
                    </div> <!-- page-banner-content -->
                </div>
            </div> <!-- row -->
            
            </div>
        </div> <!-- container -->
      
       </section>



  
    
     

        <!--Carousel Wrapper-->
        <section  class="services-area  mb-1">
            
            
    
            <div style="width: 1000px;" class="container">
                <div class="row">

                    <img style="width: 300px; " class="card-title" src="assets/images/beneficios/imagen.png" alt="Card image cap">

                    
                    <div class="col-lg-10">
                            <h1 class="lead" style="text-align: justify; font-size: 25px; font-family: Arial;">El Municipio de Villa Alemana ha creado esta nueva plataforma para que puedas acceder a todos los beneficios que tenemos para ti.

                </h1>
                <br>

                <h1 class="lead" style="text-align: justify; font-size: 25px; font-family: Arial;">
                    Si tienes Registro Social de Hogares, perteneces a la población vulnerable de la comuna o a la clase media más necesitada, consulta si eres beneficiario o inscríbete para ser evaluado y así, acceder a las opciones que el municipio tiene disponible para la comunidad.
                    <br>
                    <br>
                </h1>
                <center><a style="text-align: justify; height: 50px; font-size: 20px;"href="consultasbeneficios" class="btn btn-warning" role="button" style="color:white; font-size: 50px;"><strong>Consulta aquí</strong> <i class="fa fa-mouse-pointer" style="color: white; "></i></a></center>
                    </div>
                    
                    
                
                </div>
             </div>
        </section>