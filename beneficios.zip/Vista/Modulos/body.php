<body style="background-color: white;">
  
  
    <!--====== PAGE BANNER PART START ======-->


    <div id="ventanaModal" class="modal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">Requisitos de Postulación</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <p style="font-size: 12px;">
              
              <ul>
                <li>
                - Registro Social de Hogares hasta el <strong>70%</strong>, actualizado en la comuna.
              </li>
              <li>
                - Sobre el <strong>70%</strong>, con evaluación social y elaboración de ficha social en el marco del Estado de Catástrofe Nacional.
              </li>
              <li>
                - Situaciones especiales atendidas según criterio aplicado por Asistente Social.
              </li>
              <li>
                
              </li>
              </ul>

             

              </p>
              
          </div>
          <div class="modal-footer">
            <a href="formularioRegistro" type="button" class="btn btn-primary">ACEPTAR</a>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">CERRAR</button>
          </div>
        </div>
      </div>
    </div>



    
    
    
    







    <div id="multi-item-example" class="carousel slide carousel-multi-item" data-ride="carousel">

    <!--Controls-->
    <div class="controls-top">
      <a class="btn-floating" href="#multi-item-example" data-slide="prev"><i class="fa fa-chevron-left"></i></a>
      <a class="btn-floating" href="#multi-item-example" data-slide="next"><i class="fa fa-chevron-right"></i></a>
    </div>
    <!--/.Controls-->
  
    <!--Indicators-->
    <ol class="carousel-indicators">
      <li data-target="#multi-item-example" data-slide-to="0" class="active"></li>
      <li data-target="#multi-item-example" data-slide-to="1"></li>
      <li data-target="#multi-item-example" data-slide-to="2"></li>
    </ol>
    <!--/.Indicators-->
  
    <!--Slides-->
    <div class="carousel-inner" role="listbox">
  
      <!--First slide-->
      <div class="carousel-item active">
  
        <div class="row">
  
          <div class="col-md-3">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/2.jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Entrega de Cajas COVID-19</h4>
                <p class="card-text">
                  </p>
                
              </div>
            </div>
          </div>
  
          <div class="col-md-3 d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/3.jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Entrega de Cajas COVID-19</h4>
                <p class="card-text">
                  </p>
                
              </div>
            </div>
          </div>
  
          <div class="col-md-3 d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/4.jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Entrega de Cajas COVID-19</h4>
                <p class="card-text">
                  </p>
                
              </div>
            </div>
          </div>
  
          <div class="col-md-3 d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/5.jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Entrega de Cajas COVID-19</h4>
                <p class="card-text">
                  </p>
                
              </div>
            </div>
          </div>
        </div>
  
      </div>
      <!--/.First slide-->
  
      <!--Second slide-->
      <div class="carousel-item">
  
        <div class="row">
  
          <div class="col-md-3">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/6.jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Entrega de Cajas COVID-19</h4>
                <p class="card-text">
                  </p>
                
              </div>
            </div>
          </div>
  
          <div class="col-md-3 d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/7.jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Entrega de beneficios</h4>
                <p class="card-text">
                  </p>
                
              </div>
            </div>
          </div>
  
          <div class="col-md-3 d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/8.jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Entrega de Beneficios</h4>
                <p class="card-text">
                  </p>
                
              </div>
            </div>
          </div>
  
          <div class="col-md-3 d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/9.jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Entrega de cajas Covid- 19</h4>
                <p class="card-text">
                  </p>
                
              </div>
            </div>
          </div>
  
        </div>
  
      </div>
      <!--/.Second slide-->
  
      <!--Third slide-->
      <div class="carousel-item">
  
        <div class="row">
  
          <div class="col-md-3">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/noticia.jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Card title</h4>
                <p class="card-text">
                  </p>
               </div>
            </div>
          </div>
  
          <div class="col-md-3 d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/1.jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Card title</h4>
                <p class="card-text">
                  </p>
                
              </div>
            </div>
          </div>
  
          <div class="col-md-3 d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/noticia3.jpeg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Card title</h4>
                <p class="card-text">
                  </p>
                
              </div>
            </div>
          </div>
  
          <div class="col-md-3 d-none d-md-block">
            <div class="card mb-2">
              <img class="card-img-top" src="assets/images/noticias/noticia2.jpg"
                alt="Card image cap">
              <div class="card-body">
                <h4 class="card-title">Card title</h4>
                <p class="card-text">
                </p>
                
              </div>
            </div>
          </div>
  
        </div>
  
      </div>
      <!--/.Third slide-->
  
    </div>
    <!--/.Slides-->
  
  </div>
    <!--====== SERVICES ONE PART START ======-->




    <section class="services-area services-one mb-1" style="background-color: white;">
    <div class="container">
        <div class="row">
          <div class="col-sm">
            <div class="section-title pb-1">
                <h4 class="title">Beneficios COVID-19</h4>
                </div>
                
            <button type="button" data-toggle="modal" data-target="#ventanaModal" class="btn btn-danger btn-lg btn-block"><i class="fa fa-shield-virus">
              
            </i> Beneficios Vales de Gas y Aporte de $20.000</button>
          </div>
          <div class="col-sm">
            <div class="section-title pb-10">
                <h4 class="title">Otros Beneficios</h4>
                </div>
            <button type="button" class="btn btn-success btn-lg btn-block"><i class="fa fa-paper-plane"></i> Beneficio Agua Potable </button>
            <button type="button" class="btn btn-danger btn-lg btn-block"><i class="fa fa-paper-plane"></i>  Exensión de pago derechos de aseo </button>
            <button type="button" class="btn btn-danger btn-lg btn-block"><i class="fa fa-paper-plane"></i>  Subsidio Luz </button>
          </div>
         
        </div>
      </div>
    </section>




    <section style="background-color: white;"class="services-area services-one mb-1">
        <div class="container">
            <div class="row">
                <div class="col-lg-6">
                    <div class="section-title pb-1">
                        <h4 class="title">Municipalidad de Villa Alemana</h4>
                        <p class="text">No pierdas tu tiempo y desgaste la salud, permitenos entregar las herramientas para que puedas recibir tus beneficios de manera rapida y virtual</p>
                    </div> <!-- section title -->
                </div>
            </div> <!-- row -->
            <div class="row">
                <div class="col-lg-8">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="services-content mt-40 d-sm-flex">
                                <div class="services-icon">
                                    <i class="lni-school-compass"></i>
                                </div>
                                <div class="services-content media-body">
                                    <h4 class="services-title">Cercanía</h4>
                                    <p class="text">Estamos contigo, somos parte de tus problemáticas, pero por sobre todo de las soluciones. </p>
                                </div>
                            </div> <!-- services content -->
                        </div>
                        <div class="col-md-6">
                            <div class="services-content mt-40 d-sm-flex">
                                <div class="services-icon">
                                    <i class="lni-construction"></i>
                                </div>
                                <div class="services-content media-body">
                                    <h4 class="services-title">Efectividad</h4>
                                    <p class="text">Tú sólo debes inscribirte y el beneficio que necesitas llegará a la puerta de tu hogar.</p>
                                </div>
                            </div> <!-- services content -->
                        </div>
                        <div class="col-md-6">
                            <div class="services-content mt-40 d-sm-flex">
                                <div class="services-icon">
                                    <i class="lni-cup"></i>
                                </div>
                                <div class="services-content media-body">
                                    <h4 class="services-title">Conscientes</h4>
                                    <p class="text">En los tiempos de hoy queremos protegerte y para ello, podrás tener disponibles todos los beneficios sociales en un sólo lugar y a un sólo click.</p>
                                </div>
                            </div> <!-- services content -->
                        </div>
                        <div class="col-md-6">
                            <div class="services-content mt-40 d-sm-flex">
                                <div class="services-icon">
                                    <i class="lni-laptop-phone"></i>
                                </div>
                                <div class="services-content media-body">
                                    <h4 class="services-title">Transparencia</h4>
                                    <p class="text">Podrás revisar y certificar que todo lo que se está entregando para la comunidad está de aquí, de manera comprobable y segura</p>
                                </div>
                            </div> <!-- services content -->
                        </div>
                    </div> <!-- row -->
                </div>
            </div> <!-- row -->
        </div> <!-- container -->
        <div class="services-image d-lg-flex align-items-center">
            <div class="image">
                <img src="assets/images/beneficios/people.png" alt="Services">
            </div>
        </div> <!-- services image -->
        <p class="text-center"><a href="" target="_blank" rel="nofollow"><i class="fa fa-twitter-square"></i> #VillaAlemanaSomosTodos</a> Visita nuestras redes sociales</p>
    </section>

    </body>