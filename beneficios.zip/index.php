<?php

require_once 'Controlador/plantilla_controladora.php';

$plantilla = new Plantilla();
$plantilla -> llamarPlantilla();