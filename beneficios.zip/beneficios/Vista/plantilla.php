
<html lang="en">

<head>

    <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
     <meta name="description" content="">

     <meta name="author" content="Franco Delpin CCB-Solutions">

    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!--====== Title ======-->
    <title>Sistema de consulta para beneficios </title>

    <!--====== Favicon Icon ======-->
    <link rel="shortcut icon" href="assets/images/favicon.ico" type="image/png">

    <!--====== Bootstrap css ======-->
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">

    <!--====== Line Icons css ======-->
    <link rel="stylesheet" href="assets/css/LineIcons.css">


    <!--====== Default css ======-->
    <link rel="stylesheet" href="assets/css/default.css">

    <!--====== Style css ======-->
    <link rel="stylesheet" href="assets/css/style.css">

    <!--====== Style CSS randomizado para Villa Alemana======-->
    <link rel="stylesheet" type="text/css" href="style001.css">

    <link rel="stylesheet" type="text/css" href="assets/css/stylefont.css">

    <script src="https://use.fontawesome.com/44d7503507.js"></script>

    <script src="assets/js/scripts.js"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <link href='http://fonts.googleapis.com/css?family=Oswald:400,300,700' rel='stylesheet' type='text/css'>

</head>



    <?php
          
          $url = array();
          
          if(isset($_GET["url"])){
          
          $url = explode("/", $_GET["url"]);

              if($url[0] == "consultasbeneficios"){
                include "Modulos/".$url[0].".php";
                
              }else if($url[0] == "body"){
                include "Modulos/header.php";
                include "Modulos/body.php";
                include "Modulos/footer.php";
              }else if($url[0] == "formularioRegistro"){
                include "Modulos/header_inc.php";
                include "Modulos/".$url[0].".php";
              }else{
                print_r('<div> <h5>!Ups</h5>
                    <h4>La pagina que quieres acceder no se encuentra a tu alcance por este momento</h4>
                  </div>');
              }

            }  
          
          

          
          include "Modulos/scripts.php";
          
    ?>

       
    



</html>
