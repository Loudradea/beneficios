<?php

/*
if(isset($_POST['submit'])){
    
$url = 'http://200.24.13.60/~program1/solicitudes-api/public/ingresarpersona';
$data = array("api_token" => "WgZ3qUHdCmq0UXJE5J1ccEg7UcPb5b11rkVAV2HG",
"rut"=>"18278773-2",
"numero"=>"1",
"nombre"=>"Franco Giovanni",
"paterno"=>"Delpin",
"materno"=>"Rivera",
"fecha_nacimiento"=>"1993-3-02-",
"telefono"=>56988145456,
"email"=>"shakaespaa@gmail.com",
"direccion"=>"conspirator 3071",
"latitud"=>"-33.82828",
"longitud"=>"-73.82882",
"idcomuna"=>1,
"idbanco"=>1,
"idcuenta"=>1,
"numerocuenta"=>"020202",
"irs"=>"1",
"porcentaje"=>"74",
"idsector"=>1,
"idtipoinscripcion"=>1
);

$ch = curl_init($url); //create a new cURL resource
$payload = $data;
curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);//attach encoded JSON string to the POST fields
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json')); //set the content type to application/json
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true); //return response instead of outputting
$result = curl_exec($ch); //execute the POST request
$array = json_decode($result);
var_dump($array);




}else{



}

*/



?>
    <body>

          
      <?php

      include "header_inc.php";

      ?>
          
        </section>
        <div class="container">

                
   
                <div class="alert alert-success d-none" role="alert">
                <h4 id="titulo"class="alert-heading d-none"></h4>
                <p class="d-none">Aww yeah, you successfully read this important alert message. This example text is going to run a bit longer so that you can see how spacing within an alert works with this kind of content.</p>
                <hr>
                <p class="mb-0 d-none">Whenever you need to, be sure to use margin utilities to keep things nice and tidy.</p>
            </div>


                <div class="form-group mb-2">
                  <label for="staticEmail2" class="sr-only">Email</label>
                  <input type="text" readonly class="form-control-plaintext" value="Ingrese su rut">
                </div>
                <div class="form-group mx-sm-3 mb-2">
                  <label for="inputPassword2" class="sr-only"></label>
                  <input type="text" class="form-control" id="rut" placeholder="xxxxxxxx-x"  id="rut" name="rut" oninput="checkRut(this)">
                  
                </div>
                <button class="btn btn-primary mb-2" type="buttom" id="btnConsultar" name="btnConsultar">CONSULTAR</button>
                <br>
                <br>
                <br>
                <div id="mensajePantalla"  class="alert" ></div>
                <button class="btn btn-warning mb-2 d-none" type="buttom" id="btnEjemplo" name="btnEjemplo"><a href="formularioRegistro">INSCRIBIRSE</a></button>
                

            </div>
        </body>
    
    
    </html>
</body>


<div id="ventanaModal" class="modal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">POLITICAS DE BENEFICIO</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <p style="font-size: 12px;">
              <h4>Notificación para la postulación</h4>
              
              Con la aprobación del Concejo Municipal, 29 mil familias de la comuna, que cuenten con su Registro Social de Hogares hasta un 70%, tendrán la posibilidad de acceder al vale de gas de 15 de kilos y al subsidio de alimentos de 20 mil pesos.
              Cabe destacar que este beneficio es parte de lo que se logró financiar con la Primera Etapa del Fondo Solidario de Emergencia.

              

              </p>
              <p><strong>Si usted ha revisado si cuenta ya con beneficios vinculados a su RSH, Favor omitir esta etapa</strong></p>
          </div>
          <div class="modal-footer">
            <a href="formularioRegistro" type="button" class="btn btn-primary">ACEPTAR</a>
            <button type="button" class="btn btn-secondary" data-dismiss="modal">CERRAR</button>
          </div>
        </div>
      </div>
    </div>

<script type="text/javascript">

    $("#btnConsultar").click(function(){
        
        $.ajax({
            type:'POST',
            contentType: 'application/json',
            dataType: "json",
            crossDomain: true,
            headers: {
                    'Content-Type': 'application/json'
                    },
                url: "http://200.24.13.60/~program1/solicitudes-api/public/obtenerpersonaexisterut",
                data : JSON.stringify({
                api_token:"WgZ3qUHdCmq0UXJE5J1ccEg7UcPb5b11rkVAV2HG",
                rut: $("#rut").val()
                }),
                success: function(data) {
             
                        if(parseInt(data[0]) > 0){
                            $("#mensajePantalla").html("Persona Registrada - Usted ya se encuentra validado(a) como beneficiario(a) en el Municipio de Villa Alemana. Profesionales de la Unidad Social tomarán contacto con usted.");
                            $("#mensajePantalla").addClass("alert-success");
                            $("#mensajePantalla").removeClass("alert-danger");
                            $("#btnEjemplo").addClass("d-none");
                        }else{
                            $("#mensajePantalla").html("Persona No Registrada - Favor inscribirse");
                            $("#mensajePantalla").removeClass("alert-success");
                            $("#mensajePantalla").addClass("alert-danger");
                            $("#btnEjemplo").removeClass("d-none");
                        }
                
                    
                }
            })
    });
    

</script>




