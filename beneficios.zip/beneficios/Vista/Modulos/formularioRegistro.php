 
 <div class="container">



  <div class="form-check">

                  <div class="form-group">

                      <label class="control-label col-sm-2"><strong>RUT:</strong></label>

                      <div class="col-sm-10">
                        <input type="text" class="form-control" id="rut" name="rut" placeholder="18278772-X">
                        <br>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-4"><strong>Número de Documento:</strong></label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" id="numero" name="numero" placeholder="512.564.234">
                        <br>
                      </div>
                    </div>
                    <div class="form-group">
                      <label class="control-label col-sm-2"><strong>Nombres:</strong></label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" id="primer_nombre" name="primer_nombre" placeholder="EJ: Javier Franco Noguera">
                        <br>
                      </div>
                    </div>
                  
                    <div class="form-group">
                      <label class="control-label col-sm-2" for="pwd"><strong>Apellido Paterno</strong> </label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" id="apellido_paterno" name="apellido_paterno" placeholder="">
                        <br>
                      </div>
                    </div>
                    <div class="form-group">
                        <label class="control-label col-sm-2" for="pwd"><strong>Apellido Materno </strong></label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="apellido_materno" name="apellido_materno" placeholder="">
                          <br>
                        </div>
                      </div>
                      <div class="form-group">
                      <label class="control-label col-sm-2" for="pwd"><strong>Dirección</strong> </label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" id="direccion" name="direccion" placeholder="">
                        <br>
                      </div>
                    </div>
                      <div class="form-group">
                        <label class="control-label col-sm-2" for="pwd"><strong>Fecha de Nacimiento</strong></label>
                        <div class="col-sm-10">
                            <input id="fecha_nacimiento" type="date" class="form-control" placeholder="Fecha de Nacimiento">
                            <br>
                        </div>
                      </div>
                      <div class="form-group">
                        <label class="control-label col-sm-2" for="pwd"><strong>Correo Electrónico</strong></label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="correo" name="correo" placeholder="correo@dominio.cl">
                            <br>
                        </div>
                      </div>
                      <div class="form-group">
                      <label class="control-label col-sm-4"><strong>Número Telefónico:</strong></label>
                      <div class="col-sm-10">
                        <input type="text" class="form-control" id="telefono" name="telefono" placeholder="5698814572">
                        
                      </div>
                    </div>
                      <div class="form-group">
                          <br>
                        <label class="control-label col-sm-8"  for="pwd"><strong>Seleccionar banco y cuenta de destino para depósito </strong></label>
                        <div class="col-sm-10">
                            <p><select id="banco" name="banco" class="form-control">
                                <option value="0">Seleccionar</option>
                                <option value="1" >BANCO ESTADO</option >
                                <option value="2">BANCO DE CHILE</option >
                                <option value="3">BANCO INTERNACIONAL</option>
                                <option value="4">BANCO CREDITO E INVERSIONES</option>
                                <option value="5">BANCO BICE</option>
                                <option value="6">BANCO HSBC BANK CHILE</option>
                                <option value="7">BANCO SANTANDER</option>
                                <option value="8">BANCO ITAU</option>
                                <option value="9">BANCO SECURITY</option>
                                <option value="10">BANCO FALABELLA</option>
                                <option value="11">BANCO RIPLEEY</option>
                                <option value="12">BANCO CONSORCIO</option>
                                <option value="13">BANCO BBVA</option>
                                <option value="14">BANCO COPEUCH</option>
                                <option value="15">PREPAGO LOS HEROES</option>
                            </select></p>
                        </div>
                        <br>
                        <div class="form-group">
                            <label class="control-label col-sm-4" for="pwd"><strong>Número de Cuenta Bancaria </strong></label>
                            <div class="col-sm-10">
                              <input type="" class="form-control" id="cuenta" name="cuenta" placeholder="">
                            </div>
                            <br>
                            

                            <label class="control-label col-sm-8"  for="pwd"><strong>Tipo de Cuenta Bancaria</strong></label>
                        <div class="col-sm-10">
                            <p><select id="banco" name="banco" class="form-control">
                                <option value="0">Seleccionar</option>
                                <option value="1">Cuenta Rut</option >
                                <option value="2">Cuenta Vista</option >
                                <option value="3">Cuenta Corriente</option>
                                <option value="4">Cuenta Chequera Electrónica</option>
                                <option value="5">Cuenta De Ahorro</option>
                                
                                
                                
                            </select></p>
                        </div>

                        </strong>
                        <br>
                          <div class="form-group">
                        <label class="control-label col-sm-6" for="pwd"><strong>¿Posee Registro Social de Hogares?</strong></label>
                        <div class="col-sm-10">
                            <p><select class="form-control" id="cboxIrs">
                              <option value="1">Si</option>
                              <option value="2">No</option>
                              <option value="3">No Sabe</option> 
                            </select></p>
                        </div>






                        
                        <br>
                            <div class="form-group">
                        <label class="control-label col-sm-6" for="pwd"><strong>¿Conoces tu porcentaje de vulnerabilidad?</strong></label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="porcentaje" name="porcentaje" placeholder="EJ: 40">
                        </div>
                      </div>
                      </select>
                      </div>
                      <br>
                    <div class="form-group">
                      <div class="col-sm-offset-2 col-sm-10">
                          <button class="btn btn-primary mb-2" type="buttom" id="btnConsultar" name="btnConsultar">REGISTRAR</button>
                
                      </div>
                    </div>
                    

              </div>
              
        </div>



  <div id="ventanaModal" class="modal" tabindex="-1" role="dialog">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title">INSCRIPCIÓN EXITOSA</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">&times;</span>
            </button>
          </div>
          <div class="modal-body">
            <p style=" font-size: 12px;">
              <h4></h4>
              Usted ha sido inscrito en el Municipio de Villa Alemana.
              Profesionales de la Unidad Social evaluarán su caso y en un plazo no superior de <strong>10</strong> días habíles
              se le notificará si califica para este beneficio. 
            </p>
          </div>
          <div class="modal-footer">
            <a href="body" type="button" class="btn btn-primary">ACEPTAR</a>
            
          </div>
        </div>
      </div>
    </div>





<script>
$("#btnConsultar").click(function(){
  
        $.ajax({
            type:'POST',
            contentType: 'application/json',
            dataType: "json",
            crossDomain: true,
            headers: {
                    'Content-Type': 'application/json'
                    },
                url: "http://200.24.13.60/~program1/solicitudes-api/public/ingresarpersona",
                data : JSON.stringify({
                api_token:"WgZ3qUHdCmq0UXJE5J1ccEg7UcPb5b11rkVAV2HG",
                rut: $("#rut").val(),
                numero:$("#numero").val(),
                nombre:$("#primer_nombre").val(),
                paterno:$("#apellido_paterno").val(),
                materno:$("#apellido_materno").val(),
                fecha_nacimiento:"1989-04-12",
                telefono:459881,
                email:$("#correo").val(),
                direccion:$("#direccion").val(),
                latitud:"12",
                longitud:"12",
                idcomuna:1,
                idbanco:$("#banco").val(),
                idcuenta:$("#cuenta").val(),
                numerocuenta:$("#cuenta").val(),
                irs:1,
                porcentaje:40,
                idsector:1,
                idtipoinscripcion:1                
                }),

                  success: function(data, textStatus, xhr) {
                    
                    if(parseInt(xhr.status) == 200){
                      alert(data.error);

                    }
                    if(parseInt(xhr.status) == 201){
                      //alert("Registro Ingresado Exitosamente");
                      $('#ventanaModal').modal('show');

                    }
                  }
            })
    });        
</script>