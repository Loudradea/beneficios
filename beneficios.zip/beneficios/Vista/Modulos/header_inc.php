    <section style="background-color: cornflowerblue;"class="page-banner mb-20">
        <div class="services-image d-lg-flex align-items-center">
            <div class="image">
                
                <img style="width: 500px;" src="assets/images/logos/logo_2.png" alt="Services">
                
            </div>
        <div class="container">

            <h1 class="sub-title" style="padding-right: 50px; text-align: right; text-align: center; color: white;">VILLA ALEMANA <br>BENEFICIOS</h1><h3 class="page-title" style="color: white;"></h3>

            <div style="width: auto" class="container">

              <!--<span style="color: white; font-size: 26px;"> BENEFICIOS MUNICIPALES 2020</span>-->
              
              <!-- <button type="button" class="btn btn-primary btn-lg btn-block"><span class="add-on"><i class="fa fas-phone-volume"></i></span>Fono Atención telefonica - 800 400 050</button>-->
              <!-- <button type="button" class="btn btn-secondary btn-lg btn-block"><i class="fa fa-paper-plane"></i> beneficios@villalemana.cl</button> -->
            </div>

            
            <div style="width: 1000px" class="container">

              <!--<span style="font-size: 26px; color: white;"> beneficios@villalemana.cl </span>-->
              <img style="width: 350px;" src="assets/images/banner.png" alt="Services" align="right">
              <!-- <button type="button" class="btn btn-primary btn-lg btn-block"><span class="add-on"><i class="fa fas-phone-volume"></i></span>Fono Atención telefonica - 800 400 050</button>-->
              <!-- <button type="button" class="btn btn-secondary btn-lg btn-block"><i class="fa fa-paper-plane"></i> beneficios@villalemana.cl</button> -->
            </div>
            
            <div class="row justify-content-center">
                <div class="col-lg-12">
                    <div class="page-banner-content text-center">
                       <!--  <h3 class="page-title">Servicio e integridad</h3>-->
                    </div> <!-- page-banner-content -->
                </div>
            </div> <!-- row -->
            
        </div> <!-- container -->
      
       </section>

        <section  class="services-area  mb-1">
            
            
    
            <div style="width: 1000;" class="container">
                <div class="row">
                    <img style="width: 250px;" class="card-title" src="assets/images/images/villacelular.png">
                    
                    <div class="col-lg-8">
                            <h1 class="sub-title" style="padding: 60px; color: #4fbbff; font-size: 54px;">
                              #VillaAlemanaSomosTodos
                            </h1>
                    </div>
                    
                    
                
                </div>
             </div>
        </section>