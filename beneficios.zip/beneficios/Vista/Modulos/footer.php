<footer style="background-color: black;"class="footer-area footer-one mb-1">
        <div class="footer-widget">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-logo-support d-md-flex align-items-end justify-content-between">
                            <div class="footer-logo">
                              <h3 style="color: dodgerblue;">Atención telefonica 800 400 050</h3>
                            </div> <!-- footer logo -->
                        </div> <!-- footer logo support -->
                    </div>
                </div> <!-- row -->
                <div class="row">
                    <div class="col-xl-6 col-lg-4 col-sm-12">
                        <div class="footer-support ">
                            <span style="color:white;">Sugerencias, reclamos y consultas</span>
                            <span style="color:white;"class="mail">mesadeayuda@villalemana.cl</span>
                        </div>
                        <div class="footer-app-store">
                            <ul>
                                
                                <li><a href="#"><img src="assets/images/beneficios/app.png" style="width: 350px;" alt="play"></a></li>
                            </ul>
                        </div>
                    </div>
                   <!-- <div class="container">
                        <div class="row">
                            <div class="footer-link">
                                <ul>
                                    <li>
                                        <a href="localhost:81/beneficios/transito" style="color: white;">Dirección de transito</a>
                                    <a href="localhost:81/beneficios/ambiente" style="color: white;">Dirección de medio ambiente</a> 
                                        <a href="localhost:81/beneficios/deportes" style="color: white;">Dirección de deportes</a>
                                    </li>
                                </ul>
                            </div>
                        </div> -->
                        
                    </div>
                    <div class="col-xl-2 col-lg-2 col-sm-4">
                        <div class="footer-link">
                            <h6 class="footer-title">Municipalidad de villa Alemana</h6>
                            <ul>
                              <li><a style="color:white;"href="#">Villa Alemana Participa</a></li>
                              <li><a style="color:white;"href="#">Sitio Oficial Municipalidad</a></li>
                              <li><a style="color:white;"href="#">Clase Media Protegida</a></li>
                          </ul>
                        </div> <!-- footer link -->
                    </div>
                   
                    <div class="col-xl-2 col-lg-3 col-sm-4">
                        <div class="footer-link">
                            <h6 class="footer-title">Ayuda &amp; Soporte</h6>

                            <ul>
                                <li><a style="color:white;"href="#">Mesa de ayuda</a></li>
                                
                                <li><a style="color:white;"href="#">Terminos &amp; Condiciones</a></li>
                            </ul>
                            <h5></h5>
                            
                        </div>
                        <h5 style="color:white;">Municipalidad de Villa Alemana
                            Buenos Aires 850, Villa Alemana
                            </h5> <!-- footer link -->
                            <h1></h1>
                    
                            
                    </div>
                    <img src="assets/images/logos/ccbfooter.png" style="width: 100px; height: 100px;" alt="play">
                    <div class="footer-copyright">
                        <div class="container">
                            <div class="row">
                                <div class="col-lg-12">
                                    <div class="copyright text-center d-md-flex justify-content-between align-items-center">
                                        <p style="color:white;"class="text">Copyright © 2020 Municipalidad Villa Alemana. Todos los derechos reservados</p>
                                        <ul class="social">
                                            <li><a href=""><i class="lni-facebook-filled"></i></a></li>
                                            <li><a href=""><i class="lni-twitter-original"></i></a></li>
                                            <li><a href=""><i class="lni-instagram-original"></i></a></li>
                                            <li><a href=""><i class="lni-linkedin-original"></i></a></li>
                                        </ul>
                                    </div> <!-- copyright -->
                                </div>
                            </div> <!-- row -->
                        </div> <!-- container -->
                    </div>
                </div> <!-- row -->
            </div> <!-- container -->
        </div> <!-- footer widget -->
        
        <!-- footer copyright -->
    </footer>