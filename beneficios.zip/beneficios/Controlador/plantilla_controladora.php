<?php


class Plantilla{


	public function llamarPlantilla(){
		include "Vista/plantilla.php";
	}
}