
function validatePorcent() {
  var txt = "";
  if (document.getElementById("porcentaje").validity.rangeOverflow) {
    txt = "Valor es superior al 70% más vulnerable";
  } else {
    txt = "Usted logra calificar por ser del porcentaje más bajo";
  } 
  document.getElementById("demo").innerHTML = txt;
}



function validate(evt) {
  var theEvent = evt || window.event;

  // Handle paste
  if (theEvent.type === 'paste') {
      key = event.clipboardData.getData('text/plain');
  } else {
  // Handle key press
      var key = theEvent.keyCode || theEvent.which;
      key = String.fromCharCode(key);
  }
  var regex = /[0-9]|\./;
  if( !regex.test(key) ) {
    theEvent.returnValue = false;
    if(theEvent.preventDefault) theEvent.preventDefault();
  }
}


function checkRut(rut) {
    

    
  
// Despejar Puntos
var valor = rut.value.replace('.','');
// Despejar Guión
valor = valor.replace('-','');

// Aislar Cuerpo y Dígito Verificador
cuerpo = valor.slice(0,-1);
dv = valor.slice(-1).toUpperCase();

// Formatear RUN
rut.value = cuerpo + '-'+ dv

// Si no cumple con el mínimo ej. (n.nnn.nnn)
if(cuerpo.length < 7) { rut.setCustomValidity("RUT Incompleto"); return false;}

// Calcular Dígito Verificador
suma = 0;
multiplo = 2;

// Para cada dígito del Cuerpo
for(i=1;i<=cuerpo.length;i++) {

    // Obtener su Producto con el Múltiplo Correspondiente
    index = multiplo * valor.charAt(cuerpo.length - i);
    
    // Sumar al Contador General
    suma = suma + index;
    
    // Consolidar Múltiplo dentro del rango [2,7]
    if(multiplo < 7) { multiplo = multiplo + 1; } else { multiplo = 2; }

}

// Calcular Dígito Verificador en base al Módulo 11
dvEsperado = 11 - (suma % 11);

// Casos Especiales (0 y K)
dv = (dv == 'K')?10:dv;
dv = (dv == 0)?11:dv;

// Validar que el Cuerpo coincide con su Dígito Verificador
if(dvEsperado != dv) {
	
	rut.setCustomValidity("RUT Inválido");

}else{
	


}


	


// Si todo sale bien, eliminar errores (decretar que es válido)
rut.setCustomValidity('');


  

    
}



validarEmail = function(valor) {
     
      if(!empty(valor.trim())){
          if (!/\S+@\S+\.\S+/.test(valor.toLowerCase())){
              $("#mensajeSistema").html("Email ingresado no es Válido");
              $("#modal-mensaje-sistema").modal("show"); 
              $("#correo").val("");
             return false;
          }
      }
      
    }
    
    onlyRut  = function(id){ 
        var DataVal = document.getElementById(id).value;
        document.getElementById(id).value = DataVal.replace(/[^0-9 k-]/g,'');
    }       

    empty = function(e) {
      switch (e) {
        case "":
        case 0:
        case "0":
        case null:
        case false:
        case typeof(e) == "undefined":
          return true;
        default:
          return false;
      }
    }   
    
    var Fn = {
        // Valida el rut con su cadena completa "XXXXXXXX-X"
        validaRut : function (rutCompleto) {
            rutCompleto = rutCompleto.replace("‐","-");
            if (!/^[0-9]+[-|‐]{1}[0-9kK]{1}$/.test( rutCompleto ))
                return false;
            var tmp     = rutCompleto.split('-');
            var digv    = tmp[1]; 
            var rut     = tmp[0];
            if ( digv == 'K' ) digv = 'k' ;
            
            return (Fn.dv(rut) == digv );
        },
        dv : function(T){
            var M=0,S=1;
            for(;T;T=Math.floor(T/10))
                S=(S+T%10*(9-M++%6))%11;
            return S?S-1:'k';
        }
    }

    

  $(".no-controls").keydown(function(event) {
         
        // Desactivamos cualquier combinación con shift
        if(event.shiftKey)
            event.preventDefault();
         
        /*  
            No permite ingresar pulsaciones a menos que sean los siguientes
            KeyCode Permitidos
            keycode 8 Retroceso
            keycode 37 Flecha Derecha
            keycode 39  Flecha Izquierda
            keycode 46 Suprimir
        */
        //No permite mas de 11 caracteres Numéricos
        if (event.keyCode != 46 && event.keyCode != 8 && event.keyCode != 37 && event.keyCode != 39) 
            if($(this).val().length >= 11)
                event.preventDefault();
 
        // Solo Numeros del 0 a 9 
        if (event.keyCode < 48 || event.keyCode > 57)
            //Solo Teclado Numerico 0 a 9
            if (event.keyCode < 96 || event.keyCode > 105)
                /*  
                    No permite ingresar pulsaciones a menos que sean los siguietes
                    KeyCode Permitidos
                    keycode 8 Retroceso
                    keycode 37 Flecha Derecha
                    keycode 39  Flecha Izquierda
                    keycode 46 Suprimir
                */
                if(event.keyCode != 46 && event.keyCode != 8 && event.keyCode != 37 && event.keyCode != 39)
                    event.preventDefault();
         
         
    });



